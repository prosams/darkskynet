ADD:
- Samantha Lu
- 65725776
- Run the file named samlu.py!
- The chatbot accepts inputs such as "Is it going to rain in Detroit today?" and "What's the weather like in Ann Arbor?", so make sure that your inputs are structured in the same way that the kernel patterns are. The city names are replaceable with any city.

-------- Example interactions -------- 
User: What's the weather like in Muskegon?
Chatbot: Right now in Muskegon, it's 23.58 degrees and Clear!

User: How hot will it get in Boston today?
Chatbot: In Boston it will reach 32.28 degrees